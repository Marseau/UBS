import { ConversationRepository } from '../repositories/conversation.repository';

export class ConversationHistoryPersistence {
  constructor(private readonly repo: ConversationRepository) {}

  /**
   * Aplica regras de idempotência (hash de conteúdo por sessão)
   * e normaliza campos antes de persistir.
   */
  async saveMessage(msg: {
    tenant_id: string;
    user_id: string;
    is_from_user: boolean;
    content: string;
    message_type: 'text' | 'media' | 'system';
    conversation_context: {
      session_id: string;
      duration_minutes?: number;
    }; // JSONB field - session_id_uuid is auto-generated from session_id
    intent_detected: string | null;
    confidence_score: number | null;
    tokens_used: number;
    api_cost_usd: number;
    model_used: string | null;
    decision_method: 'flow_lock' | 'regex' | 'llm' | null;
    created_at: Date;
  }) {
    // Extract session_id from conversation_context
    const sessionId = msg.conversation_context?.session_id;
    if (!sessionId) {
      throw new Error('conversation_context.session_id is required');
    }
    
    // Idempotência básica: evita duplicar mesma resposta no mesmo ms
    const exists = await this.repo.existsSamePayloadWithinWindow(
      sessionId,
      msg.content,
      1500 /* ms */
    );
    if (exists) {
      console.log(`🔄 [IDEMPOTENT] Evitando duplicação: session=${sessionId}, content_len=${msg.content.length}`);
      return;
    }
    
    console.log(`💾 [PERSIST] Salvando mensagem: session=${sessionId}, method=${msg.decision_method}, intent=${msg.intent_detected}`);
    await this.repo.insertMessage(msg);
  }
}