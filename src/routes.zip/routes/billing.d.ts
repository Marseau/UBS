declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=billing.d.ts.map
