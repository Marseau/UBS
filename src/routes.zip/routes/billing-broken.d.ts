declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=billing-broken.d.ts.map
