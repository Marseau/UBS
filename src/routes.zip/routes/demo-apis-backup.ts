// Backup do demo-apis.ts original antes da implementação do proxy
// Backup feito em: 2025-01-08 às 13:15 UTC
// Este arquivo pode ser removido após validação do proxy