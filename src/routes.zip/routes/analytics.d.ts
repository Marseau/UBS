declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=analytics.d.ts.map
